﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace Assessment3.Entities;
public partial class Student
{
    [Key]
    public int StudentId { get; set; }

    [Required (ErrorMessage = "Please enter the name")]
    public string Name { get; set; } = null!;

    [Required (ErrorMessage ="Enter the Qualification")]
    public string? Qualification { get; set; }

    [Required(ErrorMessage ="Enter the skill")]
    public string? Skill { get; set; }
}
