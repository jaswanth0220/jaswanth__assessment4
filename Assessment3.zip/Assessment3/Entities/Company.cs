﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace Assessment3.Entities;

public partial class Company
{
    [Key]
    public int CompanyId { get; set; }
    [Required(ErrorMessage = "Please enter the name")]
    public string Name { get; set; } = null!;
    [Required(ErrorMessage = "Please enter the city")]
    public string? City { get; set; }
    [Required(ErrorMessage = "Please enter the address")]
    public string? Address { get; set; }
}
