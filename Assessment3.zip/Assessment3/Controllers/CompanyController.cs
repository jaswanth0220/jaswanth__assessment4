﻿using Assessment3.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Assessment3.Controllers
{
    public class CompanyController : Controller
    {
        private readonly ForMvcContext forMvcContext;

        public CompanyController()
        {
           forMvcContext = new ForMvcContext();
        }
        public IActionResult Index()
        {
            var companies = forMvcContext.Companies;
            return View(companies);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Company company)
        {
            forMvcContext.Companies.Add(company);
            forMvcContext.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
