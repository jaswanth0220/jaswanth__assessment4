﻿using Assessment3.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Assessment3.Controllers
{
    public class StudentController : Controller
    {
        private readonly ForMvcContext forMvcContext;

        public StudentController()
        {
            forMvcContext = new ForMvcContext();
        }
        public IActionResult Index()
        {
            var students = forMvcContext.Students;
            return View(students);
        }

        public IActionResult Details(int id)
        {
            var student = forMvcContext.Students.Single(s=>s.StudentId==id);
            return View(student);
        }
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Student student)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    forMvcContext.Students.Add(student);
                    forMvcContext.SaveChanges();
                    return RedirectToAction("Index");
                }
                else
                {
                    return View(student);
                }
            }
            catch (Exception ex) {  
                return View(student);
            }
        }

        public IActionResult Edit(int id)
        {
            var student = forMvcContext.Students.Single(s=>s.StudentId==id);
            return View(student);
        }
        [HttpPost]
        public IActionResult Edit(Student student)
        {
            try
            {
                if(ModelState.IsValid)
                    {
                    forMvcContext.Students.Update(student);
                    forMvcContext.SaveChanges();
                    return RedirectToAction("Index");
                }
                return View(student);
        }
            catch (Exception ex) {
                return View(student);
            }
            }
        public IActionResult Delete(int id)
        {

           var student = forMvcContext.Students.Single(s => s.StudentId == id);
            forMvcContext.Students.Remove(student);
            forMvcContext.SaveChanges();
            return RedirectToAction("Index");
        }}
    }
